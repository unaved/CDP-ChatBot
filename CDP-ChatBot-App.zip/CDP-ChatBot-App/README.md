# CDP Support Agent Chatbot

A chatbot that answers "how-to" questions related to Customer Data Platforms (CDPs): Segment, mParticle, Lytics, and Zeotap.

## Features

- Answers "how-to" questions for CDP platforms
- Extracts information from official documentation
- Handles platform comparisons
- Supports natural language processing
- Real-time web interface
- Automatic documentation updates

## Prerequisites

- Java 17 or higher
- Maven 3.6 or higher
- MySQL 8.0 or higher
- OpenAI API key

## OpenAI API Key Setup

1. Get your API key:
   - Go to https://platform.openai.com/
   - Sign up or log in to your OpenAI account
   - Navigate to "API Keys" section
   - Click "Create new secret key"
   - Copy your API key

2. Set up the API key (choose one method):

   Method 1 - Environment Variable (Recommended for Development):
   ```bash
   # Windows (Command Prompt)
   set OPENAI_API_KEY=your_api_key_here

   # Windows (PowerShell)
   $env:OPENAI_API_KEY="your_api_key_here"

   # Linux/Mac
   export OPENAI_API_KEY=your_api_key_here
   ```

   Method 2 - Properties File:
   - Create `src/main/resources/application-secret.properties`
   - Add your API key:
     ```properties
     openai.api.key=your_api_key_here
     ```
   - This file is git-ignored for security

## Database Setup

1. Create MySQL database and user:
```sql
CREATE DATABASE cdp_chatbot;
CREATE USER 'cdp_user'@'localhost' IDENTIFIED BY 'your_password';
GRANT ALL PRIVILEGES ON cdp_chatbot.* TO 'cdp_user'@'localhost';
FLUSH PRIVILEGES;
```

2. Configure database connection:
Edit `src/main/resources/application-secret.properties` and add:
```properties
spring.datasource.username=cdp_user
spring.datasource.password=your_password
```

## Running the Application

1. Build the project:
```bash
mvn clean install
```

2. Run the application:
```bash
mvn spring-boot:run
```

3. Access the application:
Open your browser and navigate to `http://localhost:8080`

## Usage

1. Open the chat interface by clicking "Start Chat" on the home page
2. Type your question about any of the supported CDP platforms
3. The chatbot will provide relevant information and documentation links

Example questions:
- "How do I set up a new source in Segment?"
- "How can I create a user profile in mParticle?"
- "How do I build an audience segment in Lytics?"
- "Compare audience creation in Segment and Lytics"

## Architecture

The application is built using:
- Spring Boot 3.2.3
- Thymeleaf for templating
- MySQL Database for storage
- OpenAI GPT-3.5 for natural language processing
- JSoup for web scraping

## Documentation Update

The application automatically updates its documentation database daily at midnight. You can manually trigger an update by calling:
```bash
curl -X POST http://localhost:8080/api/documentation/update
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## Security Note

Never commit your API keys or sensitive credentials to version control. The `application-secret.properties` file is included in `.gitignore` to prevent accidental commits.

## License

This project is licensed under the MIT License - see the LICENSE file for details. 
package com.cdp.chatbot.config;

import java.util.function.Function;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.web.servlet.HandlerInterceptor;

import io.github.bucket4j.Bucket;

public class RateLimitingInterceptor implements HandlerInterceptor {

    private final Function<String, Bucket> bucketResolver;

    public RateLimitingInterceptor(Function<String, Bucket> bucketResolver) {
        this.bucketResolver = bucketResolver;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String apiKey = request.getHeader("X-API-Key");
        String clientId = (apiKey != null) ? apiKey : request.getRemoteAddr();

        Bucket bucket = bucketResolver.apply(clientId);
        if (bucket.tryConsume(1)) {
            response.addHeader("X-Rate-Limit-Remaining", String.valueOf(bucket.getAvailableTokens()));
            return true;
        }

        response.setStatus(HttpStatus.TOO_MANY_REQUESTS.value());
        response.getWriter().write("Too many requests - please try again later");
        return false;
    }
} 
package com.cdp.chatbot.controller;

import com.cdp.chatbot.model.User;
import com.cdp.chatbot.model.ErrorResponse;
import com.cdp.chatbot.service.UserService;
import com.cdp.chatbot.dto.LoginRequest;
import com.cdp.chatbot.dto.RegistrationRequest;
import com.cdp.chatbot.dto.PasswordChangeRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.springframework.validation.annotation.Validated;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@Validated
public class AuthController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private UserService userService;

    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginRequest loginRequest, HttpSession session) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                    loginRequest.getUsername(),
                    loginRequest.getPassword()
                )
            );

            SecurityContextHolder.getContext().setAuthentication(authentication);
            User user = (User) authentication.getPrincipal();

            Map<String, Object> response = new HashMap<>();
            response.put("username", user.getUsername());
            response.put("roles", user.getRoles());
            response.put("sessionId", session.getId());
            response.put("message", "Login successful");

            return ResponseEntity.ok(response);
            
        } catch (AuthenticationException e) {
            return ResponseEntity.badRequest()
                .body(ErrorResponse.unauthorized("Invalid username or password"));
        }
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@Valid @RequestBody RegistrationRequest registrationRequest) {
        try {
            // Check if username exists
            if (userService.existsByUsername(registrationRequest.getUsername())) {
                return ResponseEntity.badRequest()
                    .body(ErrorResponse.badRequest("Username already exists"));
            }

            // Check if email exists
            if (userService.existsByEmail(registrationRequest.getEmail())) {
                return ResponseEntity.badRequest()
                    .body(ErrorResponse.badRequest("Email already exists"));
            }

            // Create new user
            User user = new User();
            user.setUsername(registrationRequest.getUsername());
            user.setEmail(registrationRequest.getEmail());
            user.setPassword(registrationRequest.getPassword());
            
            User registeredUser = userService.registerUser(user);

            Map<String, Object> response = new HashMap<>();
            response.put("username", registeredUser.getUsername());
            response.put("email", registeredUser.getEmail());
            response.put("message", "Registration successful");

            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(ErrorResponse.serverError("Error during registration: " + e.getMessage()));
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpServletRequest request) {
        try {
            HttpSession session = request.getSession(false);
            if (session != null) {
                session.invalidate();
            }
            SecurityContextHolder.clearContext();
            
            return ResponseEntity.ok()
                .body(Map.of("message", "Logged out successfully"));
                
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                .body(ErrorResponse.serverError("Error during logout"));
        }
    }

    @GetMapping("/user")
    public ResponseEntity<?> getCurrentUser() {
        try {
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            if (auth == null || !auth.isAuthenticated()) {
                return ResponseEntity.badRequest()
                    .body(ErrorResponse.unauthorized("No authenticated user found"));
            }

            User user = (User) auth.getPrincipal();
            Map<String, Object> response = new HashMap<>();
            response.put("username", user.getUsername());
            response.put("email", user.getEmail());
            response.put("roles", user.getRoles());

            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                .body(ErrorResponse.serverError("Error fetching user details"));
        }
    }

    @PostMapping("/change-password")
    public ResponseEntity<?> changePassword(
            @Valid @RequestBody PasswordChangeRequest passwordChangeRequest) {
        try {
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            User user = (User) auth.getPrincipal();

            if (!userService.checkPassword(user, passwordChangeRequest.getCurrentPassword())) {
                return ResponseEntity.badRequest()
                    .body(ErrorResponse.badRequest("Current password is incorrect"));
            }

            userService.changePassword(user.getUsername(), passwordChangeRequest.getNewPassword());
            
            return ResponseEntity.ok()
                .body(Map.of("message", "Password changed successfully"));
                
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                .body(ErrorResponse.serverError("Error changing password"));
        }
    }

    @PostMapping("/reset-password-request")
    public ResponseEntity<?> requestPasswordReset(@RequestParam String email) {
        try {
            if (!userService.existsByEmail(email)) {
                // For security reasons, always return success even if email doesn't exist
                return ResponseEntity.ok()
                    .body(Map.of("message", "If the email exists, a reset link will be sent"));
            }

            userService.createPasswordResetTokenForEmail(email);
            
            return ResponseEntity.ok()
                .body(Map.of("message", "If the email exists, a reset link will be sent"));
                
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                .body(ErrorResponse.serverError("Error processing password reset request"));
        }
    }
}
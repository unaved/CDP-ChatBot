package com.cdp.chatbot.service;

import com.cdp.chatbot.model.ChatMessage;
import com.cdp.chatbot.model.ChatResponse;
import com.cdp.chatbot.service.NLPService.MessageType;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ChatbotService {
    
    @Autowired
    private DocumentationService documentationService;
    
    @Autowired
    private NLPService nlpService;
    
    public ChatMessage processQuestion(String question, String sessionId) {
        try {
            log.debug("Processing question: {}", question);
            
            // Create new chat message
            ChatMessage chatMessage = new ChatMessage(question, sessionId);
            
            // Determine question type and CDP platform
            MessageType type = nlpService.determineQuestionType(question);
            String cdpPlatform = nlpService.extractCDPPlatform(question);
            
            log.debug("Question type: {}, Platform: {}", type, cdpPlatform);
            
            if (type == MessageType.IRRELEVANT) {
                chatMessage.setAnswer("I can only answer questions related to CDP platforms (Segment, mParticle, Lytics, and Zeotap). " +
                    "Please ask something specific about these platforms.");
                return chatMessage;
            }
            
            // For HOW_TO questions
            if (type == MessageType.HOW_TO) {
                if (cdpPlatform == null) {
                    chatMessage.setAnswer("Could you please specify which CDP platform you're asking about? " +
                        "(Segment, mParticle, Lytics, or Zeotap)");
                    return chatMessage;
                }
                
                String answer = documentationService.findAnswer(question, cdpPlatform);
                chatMessage.setAnswer(answer);
                chatMessage.setCdpPlatform(cdpPlatform);
                return chatMessage;
            }
            
            // For COMPARISON questions
            if (type == MessageType.COMPARISON) {
                String comparison = documentationService.compareFeatures(question);
                chatMessage.setAnswer(comparison);
                chatMessage.setCdpPlatform("multiple");
                return chatMessage;
            }
            
            chatMessage.setAnswer("I couldn't understand your question. Please try rephrasing it or ask a specific question " +
                "about how to do something in one of the CDP platforms.");
            return chatMessage;
            
        } catch (Exception e) {
            log.error("Error processing question: {}", question, e);
            ChatMessage errorMessage = new ChatMessage(question, sessionId);
            errorMessage.setAnswer("I encountered an error while processing your question. Please try again later.");
            return errorMessage;
        }
    }
} 
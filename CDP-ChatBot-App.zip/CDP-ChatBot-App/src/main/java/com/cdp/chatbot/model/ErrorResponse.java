package com.cdp.chatbot.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ErrorResponse {
    
    private int status;                // HTTP status code
    private String error;              // Error type
    private String message;            // Error message
    private String path;               // Request path
    private String method;             // HTTP method
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime timestamp;   // Error timestamp
    
    private String trace;              // Stack trace (optional)
    private Object details;            // Additional error details (optional)

    // Constructor for basic error response
    public ErrorResponse(int status, String error, String message) {
        this.status = status;
        this.error = error;
        this.message = message;
        this.timestamp = LocalDateTime.now();
    }

    // Constructor with request details
    public ErrorResponse(int status, String error, String message, String path, String method) {
        this(status, error, message);
        this.path = path;
        this.method = method;
    }

    // Static factory methods for common error scenarios
    public static ErrorResponse badRequest(String message) {
        return new ErrorResponse(400, "Bad Request", message);
    }

    public static ErrorResponse notFound(String message) {
        return new ErrorResponse(404, "Not Found", message);
    }

    public static ErrorResponse unauthorized(String message) {
        return new ErrorResponse(401, "Unauthorized", message);
    }

    public static ErrorResponse forbidden(String message) {
        return new ErrorResponse(403, "Forbidden", message);
    }

    public static ErrorResponse serverError(String message) {
        return new ErrorResponse(500, "Internal Server Error", message);
    }

    // Method to add stack trace information
    public ErrorResponse withTrace(String trace) {
        this.trace = trace;
        return this;
    }

    // Method to add additional error details
    public ErrorResponse withDetails(Object details) {
        this.details = details;
        return this;
    }

    // Method to add request information
    public ErrorResponse withRequest(String path, String method) {
        this.path = path;
        this.method = method;
        return this;
    }
} 
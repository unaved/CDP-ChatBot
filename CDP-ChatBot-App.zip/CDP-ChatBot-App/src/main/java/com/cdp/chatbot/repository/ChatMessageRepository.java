package com.cdp.chatbot.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cdp.chatbot.model.ChatMessage;

public interface ChatMessageRepository extends JpaRepository<ChatMessage, Long> {
    
    List<ChatMessage> findBySessionId(String sessionId);
    
    @Query("SELECT c FROM ChatMessage c WHERE c.sessionId = :sessionId ORDER BY c.timestamp DESC LIMIT :limit")
    List<ChatMessage> findRecentBySessionId(@Param("sessionId") String sessionId, @Param("limit") int limit);
    
    List<ChatMessage> findByCdpPlatform(String platform);
    
    @Query("SELECT DISTINCT c.sessionId FROM ChatMessage c WHERE c.timestamp >= CURRENT_DATE")
    List<String> findActiveSessionsToday();
} 
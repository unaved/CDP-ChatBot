package com.cdp.chatbot.controller;

import java.util.List;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.cdp.chatbot.model.ChatMessage;
import com.cdp.chatbot.repository.ChatMessageRepository;
import com.cdp.chatbot.service.ChatbotService;

@RestController
@RequestMapping("/api/chat")
public class ChatRestController {

    @Autowired
    private ChatbotService chatbotService;

    @Autowired
    private ChatMessageRepository chatMessageRepository;

    @PostMapping("/ask")
    @ResponseBody
    public ResponseEntity<ChatMessage> ask(@RequestParam String question, HttpSession session) {
        if (question == null || question.trim().isEmpty()) {
            return ResponseEntity.badRequest().build();
        }
        
        // Process the question and get response
        ChatMessage response = chatbotService.processQuestion(question, session.getId());
        
        // Save the chat message
        chatMessageRepository.save(response);
        
        return ResponseEntity.ok(response);
    }

    @GetMapping("/history")
    public ResponseEntity<List<ChatMessage>> getHistory(
            HttpSession session,
            @RequestParam(defaultValue = "10") int limit) {
        List<ChatMessage> history = chatMessageRepository.findRecentBySessionId(
            session.getId(),
            Math.min(limit, 50) // Cap at 50 messages
        );
        return ResponseEntity.ok(history);
    }

    @DeleteMapping("/history")
    public ResponseEntity<?> clearHistory(HttpSession session) {
        List<ChatMessage> messages = chatMessageRepository.findBySessionId(session.getId());
        chatMessageRepository.deleteAll(messages);
        return ResponseEntity.ok().build();
    }
} 
package com.cdp.chatbot.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.theokanning.openai.completion.chat.ChatCompletionRequest;
import com.theokanning.openai.completion.chat.ChatMessage;
import com.theokanning.openai.service.OpenAiService;

@Service
public class NLPService {
    
    @Autowired
    private OpenAiService openAiService;
    
    public enum MessageType {
        HOW_TO,
        COMPARISON,
        IRRELEVANT
    }
    
    private static final Set<String> CDP_PLATFORMS = new HashSet<>(Arrays.asList(
        "segment", "mparticle", "lytics", "zeotap"
    ));
    
    private static final Set<String> COMPARISON_KEYWORDS = new HashSet<>(Arrays.asList(
        "compare", "comparison", "versus", "vs", "difference", "better", "which"
    ));
    
    private static final Set<String> HOW_TO_KEYWORDS = new HashSet<>(Arrays.asList(
        "how", "guide", "tutorial", "steps", "setup", "configure", "implement", "use", "create"
    ));
    
    public MessageType determineQuestionType(String question) {
        String lowerQuestion = question.toLowerCase();
        
        if (!isRelevantToCDP(lowerQuestion)) {
            return MessageType.IRRELEVANT;
        }
        
        if (isComparisonQuestion(lowerQuestion)) {
            return MessageType.COMPARISON;
        }
        
        return MessageType.HOW_TO;
    }
    
    public String extractCDPPlatform(String question) {
        String lowerQuestion = question.toLowerCase();
        return CDP_PLATFORMS.stream()
                          .filter(lowerQuestion::contains)
                          .findFirst()
                          .map(p -> p.substring(0, 1).toUpperCase() + p.substring(1))
                          .orElse(null);
    }
    
    public List<String> extractCDPPlatforms(String question) {
        String lowerQuestion = question.toLowerCase();
        return CDP_PLATFORMS.stream()
                          .filter(lowerQuestion::contains)
                          .map(p -> p.substring(0, 1).toUpperCase() + p.substring(1))
                          .toList();
    }
    
    private boolean isRelevantToCDP(String question) {
        return CDP_PLATFORMS.stream().anyMatch(question::contains) ||
               Pattern.compile("\\b(cdp|customer data platform)\\b").matcher(question).find();
    }
    
    private boolean isComparisonQuestion(String question) {
        return COMPARISON_KEYWORDS.stream().anyMatch(question::contains) &&
               CDP_PLATFORMS.stream().filter(question::contains).count() > 1;
    }
    
    public String generateResponse(String context, String question) {
        List<ChatMessage> messages = new ArrayList<>();
        messages.add(new ChatMessage("system", "You are a CDP platform expert assistant. Provide clear, concise answers."));
        messages.add(new ChatMessage("user", "Context: " + context + "\nQuestion: " + question));
        
        ChatCompletionRequest request = ChatCompletionRequest.builder()
            .messages(messages)
            .model("gpt-3.5-turbo")
            .maxTokens(500)
            .build();
            
        return openAiService.createChatCompletion(request)
                          .getChoices().get(0)
                          .getMessage()
                          .getContent();
    }
    
    public List<String> extractKeywords(String text) {
        String[] words = text.toLowerCase().split("\\s+");
        return Arrays.stream(words)
                    .filter(word -> word.length() > 3)
                    .filter(word -> !Arrays.asList("the", "and", "for", "that", "with").contains(word))
                    .distinct()
                    .limit(10)
                    .toList();
    }
} 
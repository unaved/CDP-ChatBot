package com.cdp.chatbot.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Data;

@Data
@Configuration
@ConfigurationProperties(prefix = "openai")
public class OpenAIProperties {
    private String apiKey;
    private String model;
    private Double temperature;
    private Integer maxTokens;
    
    // Validate API key is set
    public void validateApiKey() {
        if (apiKey == null || apiKey.trim().isEmpty()) {
            throw new IllegalStateException(
                "OpenAI API key is not set. Please set the OPENAI_API_KEY environment variable " +
                "or add it to application-secret.properties"
            );
        }
    }
} 
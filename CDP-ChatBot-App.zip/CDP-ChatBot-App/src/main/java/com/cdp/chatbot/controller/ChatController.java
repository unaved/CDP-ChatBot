package com.cdp.chatbot.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cdp.chatbot.model.ChatMessage;
import com.cdp.chatbot.service.ChatbotService;

@Controller
public class ChatController {

    @Autowired
    private ChatbotService chatbotService;

    @GetMapping("/")
    public String home(Model model) {
        return "index";
    }

    @PostMapping("/ask")
    @ResponseBody
    public ChatMessage ask(@RequestParam String question, HttpSession session) {
        String sessionId = session.getId();
        return chatbotService.processQuestion(question, sessionId);
    }

    @GetMapping("/chat")
    public String chat() {
        return "chat";
    }
}
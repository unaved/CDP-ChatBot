package com.cdp.chatbot.model;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ChatResponse {
    private String message;
    private String platform;
    private String category;
    private LocalDateTime timestamp;
    private boolean isError;
    private String sourceUrl;

    public ChatResponse(String message) {
        this.message = message;
        this.timestamp = LocalDateTime.now();
        this.isError = false;
    }

    public ChatResponse(String message, String platform, String category, String sourceUrl) {
        this(message);
        this.platform = platform;
        this.category = category;
        this.sourceUrl = sourceUrl;
    }

    public static ChatResponse error(String message) {
        ChatResponse response = new ChatResponse(message);
        response.setError(true);
        return response;
    }
} 
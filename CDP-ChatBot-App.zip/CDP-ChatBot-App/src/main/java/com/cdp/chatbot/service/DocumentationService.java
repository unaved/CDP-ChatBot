package com.cdp.chatbot.service;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Value;
import lombok.extern.slf4j.Slf4j;

import com.cdp.chatbot.model.Documentation;
import com.cdp.chatbot.repository.DocumentationRepository;

@Service
@Slf4j
public class DocumentationService {
    
    @Autowired
    private DocumentationRepository documentationRepository;
    
    @Autowired
    private NLPService nlpService;
    
    @Value("${cdp.platform.segment.url}")
    private String segmentUrl;
    
    @Value("${cdp.platform.mparticle.url}")
    private String mparticleUrl;
    
    @Value("${cdp.platform.lytics.url}")
    private String lyticsUrl;
    
    @Value("${cdp.platform.zeotap.url}")
    private String zeotapUrl;
    
    // Temporary in-memory storage for documentation (should be replaced with database)
    private final Map<String, Map<String, String>> documentationStore = new HashMap<>();

    public String findAnswer(String question, String platform) {
        List<Documentation> relevantDocs = searchDocumentation(platform, extractKeywords(question));
        if (relevantDocs.isEmpty()) {
            return "I couldn't find specific information about that. Please try rephrasing your question.";
        }
        
        // Combine relevant documentation content
        String context = relevantDocs.stream()
                                   .map(Documentation::getContent)
                                   .collect(Collectors.joining("\n"));
                                   
        // Use NLP to generate a coherent response
        return nlpService.generateResponse(context, question);
    }

    public String compareFeatures(String question) {
        List<String> platforms = nlpService.extractCDPPlatforms(question);
        if (platforms.size() < 2) {
            return "Please specify which CDP platforms you'd like to compare.";
        }
        
        // Get documentation for each platform
        Map<String, List<Documentation>> platformDocs = new HashMap<>();
        for (String platform : platforms) {
            platformDocs.put(platform, documentationRepository.findByPlatform(platform));
        }
        
        // Create comparison context
        StringBuilder context = new StringBuilder("Comparison between ");
        context.append(String.join(" and ", platforms)).append(":\n");
        platformDocs.forEach((platform, docs) -> {
            context.append("\n").append(platform).append(" features:\n");
            docs.forEach(doc -> context.append("- ").append(doc.getTopic()).append(": ")
                                     .append(doc.getContent()).append("\n"));
        });
        
        // Generate comparison response
        return nlpService.generateResponse(context.toString(), question);
    }

    @Scheduled(cron = "${documentation.update.cron}")
    public void updateDocumentation() {
        try {
            updatePlatformDocs("Segment", segmentUrl);
            updatePlatformDocs("mParticle", mparticleUrl);
            updatePlatformDocs("Lytics", lyticsUrl);
            updatePlatformDocs("Zeotap", zeotapUrl);
        } catch (Exception e) {
            log.error("Error updating documentation", e);
        }
    }

    private void updatePlatformDocs(String platform, String url) {
        try {
            Document doc = Jsoup.connect(url).get();
            Map<String, String> docs = new HashMap<>();
            
            // Extract main content
            doc.select("article, .documentation-section, .doc-content").forEach(element -> {
                String title = element.select("h1, h2, h3").first().text();
                String content = element.text();
                docs.put(title, content);
            });
            
            documentationStore.put(platform, docs);
            log.info("Updated documentation for {}", platform);
        } catch (Exception e) {
            log.error("Error updating docs for " + platform, e);
        }
    }

    private String determineCategory(String content) {
        content = content.toLowerCase();
        if (content.contains("setup") || content.contains("configuration")) return "setup";
        if (content.contains("integration")) return "integration";
        if (content.contains("audience") || content.contains("segment")) return "audience";
        if (content.contains("tracking") || content.contains("analytics")) return "tracking";
        return "general";
    }

    private String extractKeywords(String text) {
        // Simple keyword extraction based on frequency and relevance
        String[] words = text.toLowerCase().split("\\s+");
        return Arrays.stream(words)
                    .filter(word -> word.length() > 3)
                    .filter(word -> !Arrays.asList("the", "and", "for", "that", "with").contains(word))
                    .distinct()
                    .limit(10)
                    .collect(Collectors.joining(","));
    }

    public List<Documentation> searchDocumentation(String platform, String keyword) {
        if (platform != null && !platform.isEmpty()) {
            return documentationRepository.searchByPlatformAndKeyword(platform, keyword);
        }
        return documentationRepository.searchByKeyword(keyword);
    }

    public List<String> extractRelevantInformation(String question) {
        // TODO: Implement logic to extract relevant keywords and context from the question
        return List.of(); // Placeholder
    }
} 
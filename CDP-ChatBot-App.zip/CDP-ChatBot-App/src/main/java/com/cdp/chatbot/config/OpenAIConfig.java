package com.cdp.chatbot.config;

import java.time.Duration;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.theokanning.openai.service.OpenAiService;

@Configuration
public class OpenAIConfig {
    
    @Autowired
    private OpenAIProperties properties;
    
    @PostConstruct
    public void validateConfig() {
        properties.validateApiKey();
    }
    
    @Bean
    public OpenAiService openAiService() {
        return new OpenAiService(properties.getApiKey(), Duration.ofSeconds(30));
    }
} 
package com.cdp.chatbot.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cdp.chatbot.model.Documentation;

public interface DocumentationRepository extends JpaRepository<Documentation, Long> {
    List<Documentation> findByPlatform(String platform);
    
    List<Documentation> findByPlatformAndCategory(String platform, String category);
    
    @Query("SELECT d FROM Documentation d WHERE " +
           "LOWER(d.content) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(d.keywords) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<Documentation> searchByKeyword(@Param("keyword") String keyword);
    
    @Query("SELECT d FROM Documentation d WHERE " +
           "d.platform = :platform AND " +
           "(LOWER(d.content) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(d.keywords) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    List<Documentation> searchByPlatformAndKeyword(
        @Param("platform") String platform,
        @Param("keyword") String keyword
    );
} 
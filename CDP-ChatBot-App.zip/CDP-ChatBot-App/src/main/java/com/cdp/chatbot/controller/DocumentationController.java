package com.cdp.chatbot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cdp.chatbot.model.Documentation;
import com.cdp.chatbot.service.DocumentationService;

@RestController
@RequestMapping("/api/documentation")
public class DocumentationController {

    @Autowired
    private DocumentationService documentationService;

    @PostMapping("/update")
    public ResponseEntity<?> updateDocumentation() {
        documentationService.updateDocumentation();
        return ResponseEntity.ok().build();
    }

    @GetMapping("/search")
    public ResponseEntity<List<Documentation>> search(
            @RequestParam(required = false) String platform,
            @RequestParam String keyword) {
        return ResponseEntity.ok(documentationService.searchDocumentation(platform, keyword));
    }

    @GetMapping("/platform/{platform}")
    public ResponseEntity<List<Documentation>> getByPlatform(
            @PathVariable String platform) {
        return ResponseEntity.ok(documentationService.searchDocumentation(platform, null));
    }
} 
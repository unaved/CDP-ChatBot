package com.cdp.chatbot.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "documentation")
public class Documentation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String platform; // Segment, mParticle, Lytics, or Zeotap

    @Column(nullable = false)
    private String topic;

    @Column(length = 1000)
    private String content;

    @Column
    private String url;

    @Column
    private String category; // e.g., "setup", "integration", "audience", etc.

    @Column(columnDefinition = "TEXT")
    private String keywords; // Comma-separated keywords for better search
}
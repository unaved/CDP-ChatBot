-- Create database if not exists
CREATE DATABASE IF NOT EXISTS cdp_chatbot;
USE cdp_chatbot;

-- Create tables
CREATE TABLE IF NOT EXISTS documentation (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    platform VARCHAR(50) NOT NULL,
    topic VARCHAR(255) NOT NULL,
    content TEXT,
    url VARCHAR(500),
    category VARCHAR(50),
    keywords TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_platform (platform),
    INDEX idx_category (category),
    FULLTEXT INDEX idx_content (content),
    FULLTEXT INDEX idx_keywords (keywords)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS chat_messages (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    question TEXT NOT NULL,
    answer TEXT,
    cdp_platform VARCHAR(50),
    session_id VARCHAR(100),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_session (session_id),
    INDEX idx_platform (cdp_platform)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create user and grant privileges (if not already done)
CREATE USER IF NOT EXISTS 'cdp_user'@'localhost' IDENTIFIED BY 'your_password';
GRANT ALL PRIVILEGES ON cdp_chatbot.* TO 'cdp_user'@'localhost';
FLUSH PRIVILEGES; 
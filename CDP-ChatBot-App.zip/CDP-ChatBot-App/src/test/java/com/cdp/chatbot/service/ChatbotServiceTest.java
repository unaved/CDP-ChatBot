package com.cdp.chatbot.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.cdp.chatbot.model.ChatResponse;

@SpringBootTest
class ChatbotServiceTest {

    @Autowired
    private ChatbotService chatbotService;

    @MockBean
    private DocumentationService documentationService;

    @MockBean
    private NLPService nlpService;

//    @Test
//    void whenQuestionIsIrrelevant_thenReturnAppropriateResponse() {
//        // Given
//        String question = "What's the weather like today?";
//        when(nlpService.determineQuestionType(any()))
//            .thenReturn(NLPService.MessageType.IRRELEVANT);
//
//        // When
//        ChatResponse response = chatbotService.processQuestion(question);
//
//        // Then
//        assertNotNull(response);
//        assertTrue(response.getMessage().contains("can only answer questions related to CDP platforms"));
//    }

//    @Test
//    void whenQuestionIsAboutSegment_thenReturnValidResponse() {
//        // Given
//        String question = "How do I set up Segment?";
//        when(nlpService.determineQuestionType(any()))
//            .thenReturn(NLPService.MessageType.HOW_TO);
//        when(nlpService.extractCDPPlatform(any()))
//            .thenReturn("Segment");
//        when(documentationService.findAnswer(any(), any()))
//            .thenReturn("Here's how to set up Segment...");
//
//        // When
//        ChatResponse response = chatbotService.processQuestion(question);
//
//        // Then
//        assertNotNull(response);
//        assertEquals("Segment", response.getPlatform());
//        assertFalse(response.isError());
//    }
} 